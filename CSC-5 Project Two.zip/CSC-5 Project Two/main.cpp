/* 
 * File:   main.cpp
 * Author: Kyle J. Janosky
 * Created on July 20, 2015, 9:11 PM
 * Purpose: To play a game of Black Jack.
 */


//System Libraries
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
//User Libraries 

//Global Constants 

//Prototype Variables 

//Execution Begins Here!
int main(int argc, char** argv) {
    
    srand(static_cast<unsigned int>(time(0)));
    
    //Read in the file with the introduction text
    ifstream infile ("intro.txt");
    string file;
    do{
        getline(infile,file);
        cout<<file<<endl;
    }while(!infile.eof());
    
    //Declare Variables 
    unsigned short SIZE=104;
    unsigned short card[SIZE];
    string playHnd[15],dealHnd[30];
    int playNum[15],dealNum[30];
    unsigned int playCrd, dealCrd,sum,dSum;
    bool hit,dHit;
    
    //Loop to assign random card values to sequential cards (shuffle deck)
    for(int i=1;i<=SIZE;i++){
        card[i]=rand()%13+1;
        
        if(card[i]<1||card[i]>13){
            cout<<"Program has generated a random number of a value that is too high"<<endl;
        }
    }
    // Player and dealer are both supplied 15 cards per hand
    // Switch statement assigns "ace", "two",..."King" to cards and assigns face card value of 10
    for(int h=1;h<=15;h++){     
    
        switch (card[h]){
            case 1:
                playNum[h]=11;
                playHnd[h]="Ace";
                break;
            case 2:
                playNum[h]=2;
                playHnd[h]="Two";
            case 3:
                playNum[h]=3;
                playHnd[h]="Three";
                break;
            case 4:
                playNum[h]=4;
                playHnd[h]="Four";
                break;
            case 5:
                playNum[h]=5;
                playHnd[h]="Five";
                break;
            case 6:
                playNum[h]=6;
                playHnd[h]="Six";
                break;
            case 7:
                playNum[h]=7;
                playHnd[h]="Seven";
                break;
            case 8:
                playNum[h]=8;
                playHnd[h]="Eight";
                break;
            case 9:
                playNum[h]=9;
                playHnd[h]="Nine";
                break;
            case 10:
                playNum[h]=10;
                playHnd[h]="Ten";
                break;
            case 11:
                playNum[h]=10;
                playHnd[h]="Jack";
                break;
            case 12:
                playNum[h]=10;
                playHnd[h]="Queen";
                break;
            case 13:
                playNum[h]=10;
                playHnd[h]="King";
                break;
            default: break;
            }
    }
    //Same as above for dealer
    for(int j=16;j<=30;j++){     
       
        switch (card[j]){
            case 1:
                dealNum[j]=11;
                dealHnd[j]="Ace";
                break;
            case 2:
                dealNum[j]=2;
                dealHnd[j]="Two";
            case 3:
                dealNum[j]=3;
                dealHnd[j]="Three";
                break;
            case 4:
                dealNum[j]=4;
                dealHnd[j]="Four";
                break;
            case 5:
                dealNum[j]=5;
                dealHnd[j]="Five";
                break;
            case 6:
                dealNum[j]=6;
                dealHnd[j]="Six";
                break;
            case 7:
                dealNum[j]=7;
                dealHnd[j]="Seven";
                break;
            case 8:
                dealNum[j]=8;
                dealHnd[j]="Eight";
                break;
            case 9:
                dealNum[j]=9;
                dealHnd[j]="Nine";
                break;
            case 10:
                dealNum[j]=10;
                dealHnd[j]="Ten";
                break;
            case 11:
                dealNum[j]=10;
                dealHnd[j]="Jack";
                break;
            case 12:
                dealNum[j]=10;
                dealHnd[j]="Queen";
                break;
            case 13:
                dealNum[j]=10;
                dealHnd[j]="King";
                break;
            default: break;
            }
    }       
    
    // Section below is actual play where player chooses whether to draw again
    
    cout<<endl;
    cout<<"You were dealt a "<<playHnd[1]<<" and "<<playHnd[2]<<endl;
    cout<<"The dealer was dealt a "<<dealHnd[16]<<" and has one face down card"<<endl;
    
    cout<<"For another card type 1 to hit and 0 to pass"<<endl;
    cin>>hit;
    
    playCrd=2;
    
    if(playNum[1]+playNum[2]==21){
        cout<<"You were dealt a blackjack you win!!!"<<endl;
    }
            
        while(hit){
            playCrd++;
            cout<<"The card you drew is a "<<playHnd[playCrd]<<endl;
                sum=0;
                for(int i=1;i<=playCrd;i++){
                   sum+=playNum[i];
                }
              cout<<"Your current hand value is "<<sum<<endl;
              if(sum>21){
                  cout<<"You lose."<<endl;
                  exit;
              }else if(playNum[1]+playNum[2]+playNum[3]==21){
        cout<<"You got a hand value of 21 you win!!!"<<endl;
              }
      
    // Below is dealer drawing if sum of cards is 17 or less
              
              dSum=0;
                for(int i=1;i<=dealCrd;i++){
                   dSum+=dealNum[i];
                }
              if(dSum>17){
                 dSum=dSum;
              }else{
                  dHit=1;
              }
              dSum=0;
              dealCrd=2;
              while(dHit){
                  dealCrd++;
                   
                  for(int i=1;i<=dealCrd;i++){
                   dSum+=dealNum[i];
                        
                        if(dSum>21){
                            cout<<"The dealer surpassed 21 You win"<<endl;
                            break;
                        }
                }
              }
        } 
    
    //Exit Stage Right!
    return 0;
}

